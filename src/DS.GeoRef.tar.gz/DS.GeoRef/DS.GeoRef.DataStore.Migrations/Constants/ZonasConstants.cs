﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DS.GeoRef.DataStore.Migrations.Constants
{
    public class ZonasConstants
    {
        public const string Centro = "01";
        public const string Norte = "02";
        public const string Oeste = "03";
        public const string Sur = "04";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DS.GeoRef.DataStore.Migrations.Constants
{
    public class ProvinciasConstants
    {
        public const string CABA = "02";
        public const string PBA = "06";
    }
}

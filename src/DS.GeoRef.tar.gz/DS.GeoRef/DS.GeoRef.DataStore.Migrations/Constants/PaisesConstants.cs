﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DS.GeoRef.DataStore.Migrations.Constants
{
    public class PaisesConstants
    {
        public const string ArgentinaCode = "032";
    }
}

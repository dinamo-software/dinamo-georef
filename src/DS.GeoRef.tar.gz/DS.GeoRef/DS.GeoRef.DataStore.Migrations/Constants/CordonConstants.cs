﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DS.GeoRef.DataStore.Migrations.Constants
{
    public class CordonConstants
    {
        public const string Primer = "01";
        public const string Segundo = "02";
        public const string Tercer = "03";
    }

}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DS.GeoRef.DataStore.Migrations.Source.ARG.DGA.DTO
{
    public class MunicipioDto
    {
        public string id { get; set; }
        public string nombre { get; set; }
    }
}

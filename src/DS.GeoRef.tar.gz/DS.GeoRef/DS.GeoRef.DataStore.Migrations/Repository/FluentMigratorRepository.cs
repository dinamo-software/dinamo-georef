﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentMigrator.Builder.Create.Index;

namespace DS.GeoRef.DataStore.Migrations.Repository
{
    public class FluentMigratorRepository
    {
}
}

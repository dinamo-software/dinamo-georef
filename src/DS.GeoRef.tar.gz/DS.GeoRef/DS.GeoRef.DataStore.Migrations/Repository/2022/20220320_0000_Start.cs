﻿using FluentMigrator;
using System;
using System.Collections.Generic;
using System.Text;

namespace DS.GeoRef.DataStore.Migrations.Repository._2022
{
    [Migration(0, "Start")]
    public class _20220320_0000_Start : Migration
    {
        public override void Up()
        {
        }

        public override void Down()
        {
        }
    }
}

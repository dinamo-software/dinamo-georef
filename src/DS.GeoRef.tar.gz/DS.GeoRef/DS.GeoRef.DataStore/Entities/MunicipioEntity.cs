﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DS.GeoRef.DataStore.Entities
{
    public class MunicipioEntity
    {
        public int id { get; set; }
        public string code { get; set; }
        public string name { get; set; }
    }
}
